"""TAHAP 10 - Diagnostik: apakah skor tinggi model masuk akal dan bukan karena kebocoran?
Input : data/train_baseline.csv, train_removed_minority.csv, val.csv, test.csv, train_augmented.csv,
        test_verification.csv (label test terkoreksi), reviews_clean.csv (rating),
        results/<mode>_predictions.csv (+ results/seed_<n>/ bila ada)
Output: results/diagnostics.md
Isi: (1) cek kebocoran, (2) pembanding sederhana (mayoritas, InSet, TF-IDF), (3) skor per lapisan kesulitan
     dengan selang kepercayaan 95% dan McNemar, (4) rating & panjang ulasan, (5) variasi seed.
Tidak ada training IndoBERT dan tidak ada yang disetel memakai test: semua pembanding dilatih di train saja."""
import json
from math import comb

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

from config import DATA, DEDUP_SIM, EXTRA_SEEDS, RESULTS, SEED, TAU
from text_utils import lexicon_score

rng = np.random.default_rng(SEED)


def macro_f1(y, p):
    f1s = []
    for c in (0, 1):
        tp = np.sum((p == c) & (y == c))
        fp, fn = np.sum((p == c) & (y != c)), np.sum((p != c) & (y == c))
        f1s.append(2 * tp / (2 * tp + fp + fn) if tp + fp + fn else 0.0)
    return float(np.mean(f1s))


def with_ci(y, p, n_boot=1000):
    """Akurasi & macro F1 + selang kepercayaan 95% bootstrap (sampel ulang ulasan test)."""
    y, p = np.asarray(y), np.asarray(p)
    idx = rng.integers(0, len(y), (n_boot, len(y)))
    accs = (y[idx] == p[idx]).mean(axis=1)
    f1s = np.array([macro_f1(y[i], p[i]) for i in idx])
    a_lo, a_hi = np.percentile(accs, [2.5, 97.5])
    f_lo, f_hi = np.percentile(f1s, [2.5, 97.5])
    return (f"{(y == p).mean():.4f} ({a_lo:.4f}-{a_hi:.4f})", f"{macro_f1(y, p):.4f} ({f_lo:.4f}-{f_hi:.4f})")


def mcnemar(y, pb, pa):
    ok_b, ok_a = pb == y, pa == y
    only_b, only_a = int((ok_b & ~ok_a).sum()), int((~ok_b & ok_a).sum())
    n, k = only_b + only_a, min(only_b, only_a)
    return only_b, only_a, (min(1.0, 2 * sum(comb(n, i) for i in range(k + 1)) / 2 ** n) if n else 1.0)


# ---------- Data: test dengan label terkoreksi verifikasi (sama seperti Tahap 8) ----------
train, removed, val = (pd.read_csv(DATA / f) for f in ["train_baseline.csv", "train_removed_minority.csv", "val.csv"])
test = pd.read_csv(DATA / "test.csv")
syn = pd.read_csv(DATA / "train_augmented.csv").query("source == 'llm_augmented'")
for mode in ["baseline", "augmented"]:
    p = pd.read_csv(RESULTS / f"{mode}_predictions.csv")
    assert (p["text"].values == test["text"].values).all(), "urutan prediksi tidak sama dengan test.csv"
    test[mode] = p["pred"].values
ver = pd.read_csv(DATA / "test_verification.csv", encoding="utf-8-sig", dtype={"verified": str})
ver_of = dict(zip(ver["id"], ver["verified"].fillna("").str.strip()))
test["v"] = test["id"].map(ver_of).fillna("")
test = test[test["v"] != "-"].copy()
test["y"] = np.where(test["v"].isin(["0", "1"]), test["v"].replace("", "0").astype(int), test["label"])
test = test.reset_index(drop=True)
y = test["y"].values

L = ["# Diagnostik model: kebocoran, tingkat kesulitan, dan pembanding", "",
     f"Test: {len(test)} ulasan (label terkoreksi verifikasi; {(test['y'] == 1).sum()} positif, {(test['y'] == 0).sum()} negatif). "
     "Selang kepercayaan 95% = bootstrap 1.000 kali.", ""]

# ---------- 1. Kebocoran ----------
other = pd.concat([train, removed, val])
vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5)).fit(pd.concat([other["text"], test["text"], syn["text"]]))


def max_sim(a, b):
    A, B = vec.transform(a), vec.transform(b)
    return np.concatenate([(A[i:i + 500] @ B.T).max(axis=1).toarray().ravel() for i in range(0, A.shape[0], 500)])


test["sim"] = max_sim(test["text"], other["text"])
test["sim_syn"] = max_sim(test["text"], syn["text"])
L += ["## 1. Cek kebocoran", "", "| Pemeriksaan | Hasil |", "|---|---|",
      f"| ID test yang muncul di train/val | {test['id'].isin(other['id']).sum()} |",
      f"| Teks test identik dengan train/val | {test['text'].isin(set(other['text'])).sum()} |",
      f"| Teks test identik dengan data sintetis | {test['text'].isin(set(syn['text'])).sum()} |",
      f"| Ulasan test hampir kembar (>= {DEDUP_SIM}) dengan train/val | {(test['sim'] >= DEDUP_SIM).sum()} |",
      f"| Ulasan test hampir kembar (>= {DEDUP_SIM}) dengan data sintetis | {(test['sim_syn'] >= DEDUP_SIM).sum()} |", ""]

# ---------- 2. Pembanding sederhana (dilatih di train baseline yang sama) ----------
majority = np.full(len(y), train["label"].mode()[0])
lex = test["text"].map(lexicon_score)
lex_pred = np.where(lex >= TAU, 1, np.where(lex <= -TAU, 0, majority[0]))   # skor ambigu -> kelas mayoritas
models = {"Kelas mayoritas (selalu negatif)": majority, "InSet Lexicon (ambigu -> mayoritas)": lex_pred}
for name, v in [("TF-IDF kata 1-2 gram + regresi logistik", TfidfVectorizer(ngram_range=(1, 2), min_df=2)),
                ("TF-IDF karakter 3-5 gram + regresi logistik", TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=2))]:
    clf = LogisticRegression(max_iter=2000, class_weight="balanced").fit(v.fit_transform(train["text"]), train["label"])
    models[name] = clf.predict(v.transform(test["text"]))
models["IndoBERT baseline"] = test["baseline"].values
models["IndoBERT + augmentasi"] = test["augmented"].values
L += ["## 2. Pembanding sederhana", "", "| Model | Accuracy (CI 95%) | Macro F1 (CI 95%) |", "|---|---|---|"]
L += [f"| {name} | {' | '.join(with_ci(y, p))} |" for name, p in models.items()]
L += ["", "Jika model sederhana sudah tinggi, tugasnya memang mudah; selisih IndoBERT dengan TF-IDF adalah nilai tambah "
      "sebenarnya dari model bahasa.", ""]

# ---------- 3. Skor per lapisan kesulitan ----------
layers = [("Seluruh test", np.ones(len(test), bool)),
          ("Sumber lexicon+llm (leksikon & Claude sepakat)", test["source"].eq("lexicon+llm").values),
          ("Sumber llm (leksikon ambigu)", test["source"].eq("llm (leksikon ambigu)").values),
          ("Sumber manual (leksikon != Claude, sulit)", test["source"].eq("manual").values),
          ("Kemiripan dengan train >= 0,7", (test["sim"] >= 0.7).values),
          ("Kemiripan dengan train 0,5-0,7", ((test["sim"] >= 0.5) & (test["sim"] < 0.7)).values),
          ("Kemiripan dengan train < 0,5 (benar-benar baru)", (test["sim"] < 0.5).values),
          ("Test sulit = manual ATAU kemiripan < 0,5", (test["source"].eq("manual") | (test["sim"] < 0.5)).values)]
L += ["## 3. Skor per lapisan kesulitan", "",
      "| Lapisan | Ulasan | Model | Accuracy (CI 95%) | Macro F1 (CI 95%) |", "|---|---|---|---|---|"]
mc = []
for name, m in layers:
    for model in ["baseline", "augmented"]:
        acc, f1 = with_ci(y[m], test[model].values[m])
        L.append(f"| {name} | {m.sum()} | {model} | {acc} | {f1} |")
    mc.append((name, *mcnemar(y[m], test["baseline"].values[m], test["augmented"].values[m])))
L += ["", "Uji McNemar baseline vs augmentasi per lapisan:", "",
      "| Lapisan | Baseline benar, aug salah | Baseline salah, aug benar | p-value | p Bonferroni |", "|---|---|---|---|---|"]
n_sub = len(mc) - 1                                    # 'Seluruh test' = hipotesis utama, tidak dikoreksi
L += [f"| {name} | {b} | {a} | {p:.4f} | {'- (uji utama)' if i == 0 else f'{min(1.0, p * n_sub):.4f}'} |"
      for i, (name, b, a, p) in enumerate(mc)]
L += ["", f"Uji utama adalah 'Seluruh test'. {n_sub} lapisan lain diuji sekaligus, sehingga peluang 'signifikan' karena "
      "kebetulan ikut naik: pakai kolom p Bonferroni (p x jumlah lapisan). Lapisan dibuat setelah melihat hasil, "
      "jadi sifatnya eksploratif, bukan bukti utama.", ""]

# ---------- 4. Rating & panjang ulasan ----------
rating = test["id"].map(dict(zip(*pd.read_csv(DATA / "reviews_clean.csv")[["id", "rating"]].T.values)))
tab = pd.crosstab(rating, test["y"])
L += ["## 4. Rating bintang vs label (deskriptif; rating TIDAK dipakai model)", "",
      "| Bintang | Negatif | Positif |", "|---|---|---|"]
L += [f"| {r} | {tab.loc[r].get(0, 0)} | {tab.loc[r].get(1, 0)} |" for r in tab.index]
not3 = rating != 3
L += ["", f"Aturan sederhana 'bintang >= 4 = positif' (tanpa bintang 3): akurasi "
      f"{((rating[not3] >= 4).astype(int) == test['y'][not3]).mean():.4f}.", "",
      "Akurasi IndoBERT baseline menurut panjang ulasan:", "", "| Panjang (kata) | Ulasan | Accuracy |", "|---|---|---|"]
n_words = test["text"].str.split().str.len()
for lo, hi in [(3, 5), (6, 10), (11, 20), (21, 40), (41, 10 ** 6)]:
    m = n_words.between(lo, hi)
    L.append(f"| {lo}-{hi if hi < 10 ** 6 else '...'} | {m.sum()} | {(test['baseline'][m] == test['y'][m]).mean():.4f} |")
L.append("")

# ---------- 5. Variasi antar seed (hanya seed yang hasilnya sudah ada) ----------
L += ["## 5. Variasi antar seed training", "", "| Seed | Mode | Accuracy | Macro F1 | FP | FN |", "|---|---|---|---|---|---|"]
for seed in [SEED] + EXTRA_SEEDS:
    folder = RESULTS if seed == SEED else RESULTS / f"seed_{seed}"
    for mode in ["baseline", "augmented"]:
        f = folder / f"{mode}_metrics.json"
        if f.exists():
            m = json.load(open(f))
            (tn, fp), (fn, tp) = m["confusion_matrix [[TN,FP],[FN,TP]]"]
            L.append(f"| {seed} | {mode} | {m['accuracy']:.4f} | {m['macro']['f1']:.4f} | {fp} | {fn} |")
        else:
            L.append(f"| {seed} | {mode} | belum dijalankan | | | |")
L += ["", "Catatan: metrik di bagian 5 memakai label test asli (2.396 ulasan) dari 06_train.py; bagian lain memakai "
      "label terkoreksi (2.395 ulasan). Selisihnya hanya 1 ulasan yang dibuang saat verifikasi."]

text = "\n".join(L)
(RESULTS / "diagnostics.md").write_text(text, encoding="utf-8")
print(text)
