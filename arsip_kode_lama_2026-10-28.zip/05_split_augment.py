"""TAHAP 5 - Split data, kurangi kelas minoritas di train, lalu augmentasi LLM.

Urutan:
  1. Group split stratified: ulasan yang sangat mirip dikelompokkan (DEDUP_SIM) dan satu kelompok
     selalu masuk partisi yang sama. Test 20%, sisanya train; 10% train jadi validation.
  2. Jika kelas minoritas di train lebih dari TARGET_RATIO (1:3) x kelas mayoritas, sebagian kelas
     minoritas di TRAIN dibuang acak sampai rasionya 1:3 (agar ketimpangan jelas & efek augmentasi terukur).
  3. Skenario 1 (baseline)  = train hasil langkah 2, tanpa augmentasi.
     Skenario 2 (augmented) = train langkah 2 + parafrase LLM dari kelas minoritas yang TERSISA,
     sampai jumlahnya = kelas mayoritas.
  Test & validation TIDAK PERNAH diubah/diaugmentasi (mencegah data leakage).

Input : data/labeled.csv
Output: data/train_baseline.csv, data/train_augmented.csv, data/val.csv, data/test.csv,
        data/train_removed_minority.csv, data/split_info.json"""
import json
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import StratifiedGroupKFold
from tqdm import tqdm

from config import (AUGMENT_WITH, DATA, DEDUP_SIM, LLM_BATCH, LLM_WORKERS, SEED, TARGET_RATIO,
                    TEST_SIZE, VAL_SIZE)
from text_utils import preprocess

df = pd.read_csv(DATA / "labeled.csv")[["id", "text", "label", "source"]].reset_index(drop=True)
vectorizer = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5)).fit(df["text"])


def max_similarity(texts, reference):
    """Untuk tiap teks: kemiripan tertinggi (cosine TF-IDF karakter) dengan teks mana pun di reference."""
    if len(texts) == 0 or len(reference) == 0:
        return np.zeros(len(texts))
    A, B = vectorizer.transform(texts), vectorizer.transform(reference)
    return np.concatenate([(A[i:i + 500] @ B.T).max(axis=1).toarray().ravel() for i in range(0, A.shape[0], 500)])


def similar_groups(texts):
    """Beri nomor kelompok: ulasan dengan kemiripan >= DEDUP_SIM (langsung atau berantai) satu kelompok."""
    X = vectorizer.transform(texts)
    parent = list(range(len(texts)))

    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for start in range(0, len(texts), 500):
        sims = (X[start:start + 500] @ X.T).toarray()
        for i, j in np.argwhere(sims >= DEDUP_SIM):
            parent[root(start + i)] = root(j)
    return [root(i) for i in range(len(texts))]


def group_split(data, n_folds):
    """Ambil 1/n_folds data sebagai partisi baru, stratified per label, kelompok tidak dipecah."""
    folds = StratifiedGroupKFold(n_splits=n_folds, shuffle=True, random_state=SEED)
    rest, part = next(folds.split(data, data["label"], data["group"]))
    return data.iloc[rest], data.iloc[part]


# ---------- 1. Group split ----------
df["group"] = similar_groups(df["text"].tolist())
n_groups = df["group"].nunique()
print(f"{len(df)} ulasan -> {n_groups} kelompok ({len(df) - n_groups} ulasan punya kembaran mirip >= {DEDUP_SIM})")
train, test = group_split(df, round(1 / TEST_SIZE))
train, val = group_split(train, round(1 / VAL_SIZE))
print(f"Split -> train {len(train)}, val {len(val)}, test {len(test)}")
leak = (max_similarity(test["text"], train["text"]) >= DEDUP_SIM).sum()
print(f"Cek kebocoran: ulasan test yang mirip (>= {DEDUP_SIM}) dengan train = {leak}")
train, val, test = (d.drop(columns="group") for d in (train, val, test))

# ---------- 2. Kurangi kelas minoritas agar timpang 1:3 ----------
counts = train["label"].value_counts()
major, minor = counts.idxmax(), counts.idxmin()
print(f"Train: kelas {major} = {counts[major]}, kelas {minor} = {counts[minor]}, rasio = {counts[minor] / counts[major]:.2f}")
removed = train.iloc[0:0]
if counts[minor] / counts[major] > TARGET_RATIO:
    keep = int(counts[major] * TARGET_RATIO)
    minority = train[train["label"] == minor]
    kept = minority.sample(keep, random_state=SEED)
    removed = minority.drop(kept.index)
    train = pd.concat([train[train["label"] == major], kept])
    counts = train["label"].value_counts()
    print(f"Kelas minoritas dikurangi {len(removed)} data -> tersisa {keep}. Rasio baru = {counts[minor] / counts[major]:.2f}")
else:
    print("Sudah cukup timpang -> tidak ada data yang dibuang")
train = train.sample(frac=1, random_state=SEED).reset_index(drop=True)

# Simpan data skenario baseline sekarang (training baseline bisa jalan sambil menunggu augmentasi)
train.to_csv(DATA / "train_baseline.csv", index=False)
val.to_csv(DATA / "val.csv", index=False)
test.to_csv(DATA / "test.csv", index=False)
removed.to_csv(DATA / "train_removed_minority.csv", index=False)

# ---------- 3. Augmentasi LLM untuk kelas minoritas ----------
n_needed = counts[major] - counts[minor]
minor_texts = train.loc[train["label"] == minor, "text"].tolist()
sentiment = "positif" if minor == 1 else "negatif"

STYLES = ["ubah susunan kalimat dan pilihan kata", "pakai gaya santai/informal pengguna biasa",
          "ringkas tapi tetap jelas", "tambahkan sedikit detail situasi yang masuk akal"]
PROMPT = """Tulis ulang setiap ulasan aplikasi Gojek berikut menjadi SATU versi baru.
Aturan: sentimen tetap {sentiment}, makna inti sama, bahasa Indonesia, panjang mirip,
huruf kecil tanpa emoji, {style}. Jangan menyalin kalimat asli.
Balas HANYA JSON list: [{{"i": 0, "text": "..."}}, ...]

Ulasan:
{reviews}"""


def paraphrase(job):
    """Jalur Gemini: kembalikan pasangan (teks sumber, parafrase)."""
    from llm import ask_json          # baru dimuat kalau memang perlu memanggil API
    texts, style = job
    reviews = "\n".join(f"{i}. {t}" for i, t in enumerate(texts))
    answer = ask_json(PROMPT.format(sentiment=sentiment, style=style, reviews=reviews))
    out = []
    for item in answer or []:
        try:
            out.append((texts[int(item["i"])], preprocess(item["text"])))
        except (KeyError, TypeError, ValueError, IndexError):
            continue
    return out


# Parafrase hanya boleh berasal dari minoritas yang TERSISA (bukan dari data yang sudah dibuang),
# tidak boleh sama dengan teks mana pun di train/val/test, dan minimal 3 kata.
seen = set(train["text"]) | set(val["text"]) | set(test["text"]) | set(removed["text"])
allowed = set(minor_texts)
pairs = []                                             # (sumber, parafrase)
aug_cache = DATA / "augmented_cache.csv"


eval_texts = pd.concat([val["text"], test["text"]])


def add_pairs(rows):
    rows = [(s, t) for s, t in rows if s in allowed and isinstance(t, str) and len(t.split()) >= 3]
    sims = max_similarity([t for _, t in rows], eval_texts)   # jangan sampai mirip ulasan val/test
    for (src, t), sim in zip(rows, sims):
        if t not in seen and sim < DEDUP_SIM:
            seen.add(t)
            pairs.append((src, t))


if aug_cache.exists():
    cache = pd.read_csv(aug_cache)
    add_pairs(zip(cache["source"], cache["text"]))
    print(f"Cache augmentasi: {len(pairs)} parafrase valid (dari minoritas yang tersisa)")

if len(pairs) < n_needed and AUGMENT_WITH == "claude":
    # Ekspor teks sumber untuk ditulis ulang oleh Claude di chat (lihat README, Tahap 5)
    in_dir, out_dir = DATA / "aug_in", DATA / "aug_out"
    in_dir.mkdir(exist_ok=True)
    waiting = [f.name for f in sorted(in_dir.glob("part_*.txt")) if not (out_dir / f.name).exists()]
    if waiting:
        print(f"\nMasih menunggu hasil Claude untuk: {', '.join(waiting)}. Isi data/aug_out/ dulu, lalu jalankan 05b.")
        raise SystemExit
    short = n_needed - len(pairs)
    have = pd.Series([s for s, _ in pairs]).value_counts().to_dict()
    sources = []                                       # dahulukan ulasan yang parafrasenya paling sedikit
    for r in range(10):
        sources += [t for t in minor_texts if have.get(t, 0) <= r]
    sources = sources[:int(short * 1.15) + 1]          # lebihkan 15% untuk cadangan duplikat
    first = len(list(in_dir.glob("part_*.txt"))) + 1
    per_file = 500
    for n, start in enumerate(range(0, len(sources), per_file), first):
        lines = [f"{i}\t{STYLES[(start + i + n) % len(STYLES)]}\t{t}" for i, t in enumerate(sources[start:start + per_file])]
        (in_dir / f"part_{n}.txt").write_text("\n".join(lines), encoding="utf-8")
    print(f"\nPerlu {short} parafrase lagi (kelas {sentiment}). {len(sources)} teks sumber diekspor ke "
          f"data/aug_in/part_{first}..part_{n}.txt")
    print("Setelah Claude menulis hasil ke data/aug_out/, jalankan 05b_claude_aug_import.py lalu skrip ini lagi.")
    raise SystemExit

round_no = 0
while len(pairs) < n_needed and round_no < 8:          # jalur Gemini
    short = n_needed - len(pairs)
    n_jobs = int(short * 1.2 / LLM_BATCH) + 1
    jobs = []
    for k in range(n_jobs):                            # putar daftar minoritas, ganti gaya tiap putaran
        start = (k * LLM_BATCH) % len(minor_texts)
        chunk = (minor_texts * 2)[start:start + LLM_BATCH]
        jobs.append((chunk, STYLES[(round_no + k) % len(STYLES)]))
    with ThreadPoolExecutor(LLM_WORKERS) as pool:
        for res in tqdm(pool.map(paraphrase, jobs), total=len(jobs), desc=f"Augmentasi ronde {round_no + 1}"):
            add_pairs(res)
    pd.DataFrame(pairs, columns=["source", "text"]).to_csv(aug_cache, index=False)
    round_no += 1

pairs = pairs[:n_needed]
aug = pd.DataFrame({"text": [t for _, t in pairs], "label": minor, "source": "llm_augmented"})
print(f"Data sintetis dipakai: {len(aug)} dari target {n_needed} "
      f"(dari {len({s for s, _ in pairs})} ulasan sumber)")

train_aug = pd.concat([train, aug]).sample(frac=1, random_state=SEED).reset_index(drop=True)

# ---------- Simpan ----------
train_aug.to_csv(DATA / "train_augmented.csv", index=False)
info = {"minority_label": int(minor), "majority_label": int(major),
        "minority_removed_from_train": len(removed),
        "train_baseline": train["label"].value_counts().to_dict(),
        "train_augmented": train_aug["label"].value_counts().to_dict(),
        "val": val["label"].value_counts().to_dict(), "test": test["label"].value_counts().to_dict()}
json.dump(info, open(DATA / "split_info.json", "w"), indent=2, default=int)
print(json.dumps(info, indent=2, default=int))
