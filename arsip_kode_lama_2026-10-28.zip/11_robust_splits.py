"""TAHAP 11 - Uji ketahanan split: apakah skor tetap tinggi bila data dibagi lebih ketat?
Varian (BASELINE saja, aturan pengurangan minoritas 1:3 sama dengan tahap 5, seed sama):
  robust_dedup08 : group split dengan kemiripan >= 0,8 (lebih ketat dari DEDUP_SIM 0,9)
  robust_waktu   : test = 20% ulasan TERBARU; train & validasi = ulasan yang lebih lama (validasi acak 10%)
Pemakaian:
  python 11_robust_splits.py                     -> buat data/robust_<varian>/ (sekali, tidak ditimpa) + laporan
  DATA_DIR=data/robust_dedup08 python 06_train.py --mode baseline --tag robust_dedup08
  DATA_DIR=data/robust_waktu   python 06_train.py --mode baseline --tag robust_waktu
  python 11_robust_splits.py                     -> laporan lengkap dengan hasil IndoBERT -> results/robustness.md
Split utama (data/train_baseline.csv, val.csv, test.csv) tidak diubah."""
import json

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedGroupKFold, train_test_split

from config import DATA, DEDUP_SIM, EXTRA_SEEDS, RESULTS, SEED, TARGET_RATIO, TEST_SIZE, VAL_SIZE

df = pd.read_csv(DATA / "labeled.csv")[["id", "text", "label", "source"]]
ver = pd.read_csv(DATA / "test_verification.csv", encoding="utf-8-sig", dtype={"verified": str})
df = df[~df["id"].isin(ver.loc[ver["verified"].str.strip() == "-", "id"])].reset_index(drop=True)   # dibuang saat verifikasi
dates = pd.read_csv(DATA / "reviews_raw.csv").set_index("id")["date"]
df["date"] = pd.to_datetime(df["id"].map(dates))
vectorizer = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5)).fit(df["text"])


def max_similarity(texts, reference):
    A, B = vectorizer.transform(texts), vectorizer.transform(reference)
    return np.concatenate([(A[i:i + 500] @ B.T).max(axis=1).toarray().ravel() for i in range(0, A.shape[0], 500)])


def similar_groups(texts, threshold):
    """Sama seperti tahap 5: ulasan dengan kemiripan >= threshold (langsung/berantai) satu kelompok."""
    X = vectorizer.transform(texts)
    parent = list(range(len(texts)))

    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for start in range(0, len(texts), 500):
        for i, j in np.argwhere((X[start:start + 500] @ X.T).toarray() >= threshold):
            parent[root(start + i)] = root(j)
    return [root(i) for i in range(len(texts))]


def group_split(data, n_folds):
    rest, part = next(StratifiedGroupKFold(n_splits=n_folds, shuffle=True, random_state=SEED)
                      .split(data, data["label"], data["group"]))
    return data.iloc[rest], data.iloc[part]


def reduce_minority(train):
    """Sama seperti tahap 5: kelas minoritas di train dikurangi acak sampai TARGET_RATIO (1:3)."""
    counts = train["label"].value_counts()
    major, minor = counts.idxmax(), counts.idxmin()
    if counts[minor] / counts[major] > TARGET_RATIO:
        kept = train[train["label"] == minor].sample(int(counts[major] * TARGET_RATIO), random_state=SEED)
        train = pd.concat([train[train["label"] == major], kept])
    return train.sample(frac=1, random_state=SEED).reset_index(drop=True)


def build(name):
    out = DATA / name
    if out.exists():                                    # jangan menimpa split yang mungkin sudah dipakai training
        return
    if name == "robust_dedup08":
        data = df.assign(group=similar_groups(df["text"].tolist(), 0.8))
        train, test = group_split(data, round(1 / TEST_SIZE))
        train, val = group_split(train, round(1 / VAL_SIZE))
    else:                                               # robust_waktu
        cut = df["date"].quantile(1 - TEST_SIZE)
        test, train = df[df["date"] >= cut], df[df["date"] < cut]
        train, val = train_test_split(train, test_size=VAL_SIZE, stratify=train["label"], random_state=SEED)
    out.mkdir()
    cols = ["id", "text", "label", "source"]
    reduce_minority(train)[cols].to_csv(out / "train_baseline.csv", index=False)
    val[cols].to_csv(out / "val.csv", index=False)
    test[cols].to_csv(out / "test.csv", index=False)
    print(f"{name}: dibuat di {out}")


VARIANTS = [("Split utama (group, kemiripan 0,9)", DATA, ""),
            ("Group split lebih ketat (kemiripan 0,8)", DATA / "robust_dedup08", "robust_dedup08"),
            ("Split menurut waktu (test = 20% terbaru)", DATA / "robust_waktu", "robust_waktu")]
for _, folder, tag in VARIANTS[1:]:
    build(tag)

date_of = dict(zip(df["id"], df["date"]))
L = ["# Uji ketahanan split (baseline IndoBERT)", "",
     "Pertanyaan: apakah skor ±98% bertahan bila split dibuat lebih ketat? Ketiga varian memakai aturan 1:3 dan seed yang sama; "
     "isi test berbeda, jadi bandingkan pola, bukan angka persis. TF-IDF + regresi logistik dilatih di train varian yang sama "
     "sebagai ukuran tingkat kesulitan test.", "",
     "| Varian | Train (neg/pos) | Test (neg/pos) | Rentang tanggal test | Test mirip train >= 0,9 | >= 0,8 | "
     "TF-IDF macro F1 | IndoBERT accuracy | IndoBERT macro F1 | Recall positif | Akurasi sumber manual |",
     "|---|---|---|---|---|---|---|---|---|---|---|"]
for name, folder, tag in VARIANTS:
    train, val, test = (pd.read_csv(folder / f) for f in ["train_baseline.csv", "val.csv", "test.csv"])
    others = pd.concat([train, val, pd.read_csv(DATA / "train_removed_minority.csv")]) if tag == "" else pd.concat([train, val])
    sims = max_similarity(test["text"], others["text"])
    tfidf = TfidfVectorizer(ngram_range=(1, 2), min_df=2)
    clf = LogisticRegression(max_iter=2000, class_weight="balanced").fit(tfidf.fit_transform(train["text"]), train["label"])
    tf_f1 = f1_score(test["label"], clf.predict(tfidf.transform(test["text"])), average="macro")
    d = test["id"].map(date_of)
    row = (f"| {name} | {(train['label'] == 0).sum()}/{(train['label'] == 1).sum()} | "
           f"{(test['label'] == 0).sum()}/{(test['label'] == 1).sum()} | {d.min():%d-%m-%Y} s.d. {d.max():%d-%m-%Y} | "
           f"{(sims >= DEDUP_SIM).sum()} | {(sims >= 0.8).sum()} | {tf_f1:.4f} | ")
    res = RESULTS / tag
    if (res / "baseline_metrics.json").exists():
        m = json.load(open(res / "baseline_metrics.json"))
        p = pd.read_csv(res / "baseline_predictions.csv")
        manual = (test["source"] == "manual").values
        row += (f"{m['accuracy']:.4f} | {m['macro']['f1']:.4f} | {m['per_class']['positif']['recall']:.4f} | "
                f"{(p['pred'].values[manual] == p['label'].values[manual]).mean():.4f} |")
    else:
        row += "belum dilatih | | | |"
    L.append(row)

seed_f1 = [json.load(open((RESULTS if s == SEED else RESULTS / f"seed_{s}") / "baseline_metrics.json"))["macro"]["f1"]
           for s in [SEED] + EXTRA_SEEDS if ((RESULTS if s == SEED else RESULTS / f"seed_{s}") / "baseline_metrics.json").exists()]
L += ["", f"Pembanding variasi: macro F1 baseline split utama antar seed {min(seed_f1):.4f}-{max(seed_f1):.4f} "
      f"({len(seed_f1)} seed). Penurunan varian yang masih dalam rentang ini berarti skor tidak bergantung pada split.",
      "", "Catatan: split utama memakai label test terkoreksi untuk 1 ulasan yang dibuang; varian lain membuang ulasan itu dari dataset. "
      "Split waktu tidak memakai pengelompokan ulasan mirip, karena ulasan berpola sama memang muncul lagi di dunia nyata."]
text = "\n".join(L)
(RESULTS / "robustness.md").write_text(text, encoding="utf-8")
print(text)
