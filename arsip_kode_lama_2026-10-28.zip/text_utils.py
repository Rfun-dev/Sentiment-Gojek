"""Fungsi teks yang dipakai beberapa tahap: preprocessing dan skor leksikon."""
import re
from functools import lru_cache

import pandas as pd

from config import RESOURCES

# Kata negasi dipaksa jadi "tidak" supaya konsisten dengan proposal.
OVERRIDES = {w: "tidak" for w in ["gak", "ga", "gk", "nggak", "ngga", "enggak", "tak", "tdk"]}
OVERRIDES["gabisa"] = "tidak bisa"


@lru_cache(maxsize=1)
def load_slang():
    """Kamus slang -> baku dari IndoCollex (ambil bentuk baku paling sering muncul)."""
    df = pd.read_csv(RESOURCES / "indocollex.csv")
    df = df[(df["In-dictionary"] == 1) & (df["slang"] != df["formal"])]
    slang = df.groupby("slang")["formal"].agg(lambda s: s.mode().iloc[0]).to_dict()
    slang.update(OVERRIDES)
    return slang


# InSet memuat kata fungsi/netral dengan bobot besar (mis. "yang" = -5). Kata-kata ini dibuang
# agar skor leksikon tidak menyesatkan. Ditentukan dari kata paling sering di korpus ulasan.
NOISE_WORDS = set("""yang saya aplikasi saja lagi sama dari lebih ya buat itu kalau sekali apa harus pada semua lain
ambil dalam cari mencari sistem chat titik tau datang pun pihak begini makanan masuk cuma hanya harga pelayanan
promo diskon saldo layanan tetap langsung pas terima kadang sendiri seperti kayak sering meminta""".split())


@lru_cache(maxsize=1)
def load_inset():
    """InSet Lexicon: dict kata -> bobot (-5..+5).
    Dibuang: kata majemuk, kata yang ada di daftar positif DAN negatif (ambigu, mis. "bagus" +2 / -4),
    dan kata fungsi/netral di NOISE_WORDS."""
    pos = pd.read_csv(RESOURCES / "inset_positive.tsv", sep="	")
    neg = pd.read_csv(RESOURCES / "inset_negative.tsv", sep="	")
    ambiguous = set(pos["word"]) & set(neg["word"])
    both = pd.concat([pos, neg])
    both = both[~both["word"].str.contains(" ") & ~both["word"].isin(ambiguous | NOISE_WORDS)]
    return dict(zip(both["word"], both["weight"]))


def clean_text(text: str) -> str:
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)   # URL
    text = re.sub(r"[@#]\w+", " ", text)                  # mention & hashtag
    text = re.sub(r"\d+", " ", text)                      # angka
    text = re.sub(r"[^a-zA-Z\s]", " ", text)              # selain huruf (spasi agar kata tidak menempel)
    return re.sub(r"\s+", " ", text).strip()


def normalize_slang(text: str) -> str:
    slang = load_slang()
    return " ".join(slang.get(tok, tok) for tok in text.split())


def preprocess(text: str) -> str:
    """cleaning -> case folding -> normalisasi slang"""
    return normalize_slang(clean_text(str(text)).lower())


def lexicon_score(text: str) -> int:
    """Jumlah bobot InSet dari semua kata di teks (persamaan 3.1 proposal)."""
    inset = load_inset()
    return sum(inset.get(tok, 0) for tok in text.split())
