"""TAHAP 12 - Test ulasan baru berlabel buta: bukti terakhir bahwa skor model berlaku di luar dataset.
Pemakaian:
  python 12_fresh_test.py scrape     -> ulasan yang terbit SETELAH ulasan terakhir di reviews_raw.csv
                                        -> data/fresh/reviews_fresh.csv + lembar label data/fresh/fresh_labels.csv
  (manusia mengisi kolom `label` di fresh_labels.csv: 1 positif, 0 negatif, - netral/campur/tidak jelas,
   hanya dari raw_text, tanpa melihat rating, label leksikon/Claude, atau prediksi model)
  python 12_fresh_test.py evaluate   -> semua model IndoBERT + pembanding sederhana -> results/fresh_test.md
Model tidak dilatih ulang dan tidak ada yang disetel memakai data ini.
Kolom opsional `koreksi`: label yang diperbaiki SETELAH prediksi terlihat. Hanya dilaporkan sebagai angka tambahan;
angka utama tetap memakai `label` (buta)."""
import argparse
import json
import time
from math import comb, sqrt

import numpy as np
import pandas as pd

from config import (DATA, EXTRA_SEEDS, FRESH_SIZE, MAX_LEN, MIN_WORDS, MODELS, RESULTS, SEED, TAU, APP_ID)
from text_utils import lexicon_score, preprocess

FRESH = DATA / "fresh"
LABELS = FRESH / "fresh_labels.csv"


def scrape():
    from google_play_scraper import Sort, reviews

    if LABELS.exists():                                 # lembar label mungkin sudah diisi -> jangan ditimpa
        print(f"{LABELS} sudah ada, tidak diambil ulang.")
        return
    old = pd.read_csv(DATA / "reviews_raw.csv")
    cutoff = pd.to_datetime(old["date"]).max()
    rows, token = [], None
    while True:                                         # urut terbaru; berhenti saat sampai ulasan lama
        try:
            batch, token = reviews(APP_ID, lang="id", country="id", sort=Sort.NEWEST, count=200, continuation_token=token)
        except Exception as e:
            print("Error:", e, "- ulangi 10 detik lagi")
            time.sleep(10)
            continue
        rows += batch
        print(f"  diambil {len(rows)} ulasan, terlama {batch[-1]['at'] if batch else '-'}", flush=True)
        if not batch or token is None or pd.Timestamp(batch[-1]["at"]) <= cutoff:
            break
    df = pd.DataFrame(rows)[["reviewId", "content", "score", "at"]].dropna(subset=["content"])
    df = df.rename(columns={"reviewId": "id", "content": "raw_text", "score": "rating", "at": "date"})
    df = df[(pd.to_datetime(df["date"]) > cutoff) & ~df["id"].isin(old["id"])]
    print(f"Ulasan setelah {cutoff}: {len(df)}")

    # preprocessing sama dengan tahap 2; teks yang identik dengan dataset lama ikut dibuang (tahap 2 juga membuang duplikat)
    df["text"] = df["raw_text"].astype(str).map(preprocess)
    df = df[df["text"].str.split().str.len() >= MIN_WORDS].drop_duplicates(subset="text")
    df = df[~df["text"].isin(set(pd.read_csv(DATA / "reviews_clean.csv")["text"]))]
    print(f"Setelah buang < {MIN_WORDS} kata & duplikat: {len(df)}")
    FRESH.mkdir(exist_ok=True)
    df[["id", "raw_text", "text", "rating", "date"]].to_csv(FRESH / "reviews_fresh.csv", index=False)

    sample = df.sample(min(FRESH_SIZE, len(df)), random_state=SEED).reset_index(drop=True)
    sample.insert(0, "no", range(1, len(sample) + 1))
    sample["label"] = ""
    sample[["no", "id", "raw_text", "label"]].to_csv(LABELS, index=False, encoding="utf-8-sig")
    print(f"Lembar label: {LABELS} ({len(sample)} ulasan, tanggal {sample['date'].min()} s.d. {sample['date'].max()})")


def wilson(ok, n, z=1.96):
    """Proporsi ok/n + selang kepercayaan 95% Wilson (sama seperti tahap 8)."""
    p = ok / n
    centre = (p + z * z / (2 * n)) / (1 + z * z / n)
    half = z * sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return f"{p:.4f} ({centre - half:.4f}-{min(1, centre + half):.4f})"


def macro_f1(y, p):
    f1s = []
    for c in (0, 1):
        tp, fp, fn = np.sum((p == c) & (y == c)), np.sum((p == c) & (y != c)), np.sum((p != c) & (y == c))
        f1s.append(2 * tp / (2 * tp + fp + fn) if tp + fp + fn else 0.0)
    return float(np.mean(f1s))


def f1_ci(y, p, n_boot=1000):
    """Macro F1 + selang kepercayaan 95% bootstrap (sama seperti tahap 10)."""
    idx = np.random.default_rng(SEED).integers(0, len(y), (n_boot, len(y)))
    lo, hi = np.percentile([macro_f1(y[i], p[i]) for i in idx], [2.5, 97.5])
    return f"{macro_f1(y, p):.4f} ({lo:.4f}-{hi:.4f})"


def mcnemar(y, pb, pa):
    only_b, only_a = int(((pb == y) & (pa != y)).sum()), int(((pb != y) & (pa == y)).sum())
    n, k = only_b + only_a, min(only_b, only_a)
    return only_b, only_a, (min(1.0, 2 * sum(comb(n, i) for i in range(k + 1)) / 2 ** n) if n else 1.0)


def performance(y, preds):
    rows = ["| Model | Accuracy (CI 95%) | Macro F1 (CI 95%) | Recall positif | FP | FN |", "|---|---|---|---|---|---|"]
    for name, p in preds.items():
        tp = int(((p == 1) & (y == 1)).sum())
        rows.append(f"| {name} | {wilson(int((p == y).sum()), len(y))} | {f1_ci(y, p)} | {tp / max(1, (y == 1).sum()):.4f} | "
                    f"{int(((p == 1) & (y == 0)).sum())} | {int(((p == 0) & (y == 1)).sum())} |")
    return rows


def indobert_predict(folder, texts):
    import torch
    from transformers import BertForSequenceClassification, BertTokenizer

    device = "cuda" if torch.cuda.is_available() else "cpu"
    tokenizer = BertTokenizer.from_pretrained(folder)
    model = BertForSequenceClassification.from_pretrained(folder).to(device).eval()
    preds = []
    with torch.no_grad():
        for i in range(0, len(texts), 32):
            enc = tokenizer(texts[i:i + 32], truncation=True, max_length=MAX_LEN, padding=True, return_tensors="pt").to(device)
            preds.append(model(**enc).logits.argmax(1).cpu().numpy())
    del model
    torch.cuda.empty_cache()
    return np.concatenate(preds)


def evaluate():
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression

    sheet = pd.read_csv(LABELS, encoding="utf-8-sig", dtype={"label": str, "koreksi": str})
    sheet["label"] = sheet["label"].fillna("").str.strip()
    assert sheet["label"].isin(["0", "1", "-", ""]).all(), "label hanya boleh 1, 0, - atau kosong"
    fresh = pd.read_csv(FRESH / "reviews_fresh.csv").set_index("id")
    sheet = sheet.join(fresh[["text", "rating", "date"]], on="id")
    filled = sheet[sheet["label"] != ""]
    test = filled[filled["label"] != "-"].reset_index(drop=True)
    y, texts = test["label"].astype(int).values, test["text"].tolist()

    # ---------- Prediksi ----------
    train = pd.read_csv(DATA / "train_baseline.csv")
    majority = int(train["label"].mode()[0])
    lex = test["text"].map(lexicon_score)
    preds = {"Kelas mayoritas (selalu negatif)": np.full(len(y), majority),
             "InSet Lexicon (ambigu -> mayoritas)": np.where(lex >= TAU, 1, np.where(lex <= -TAU, 0, majority)).astype(int)}
    tfidf = TfidfVectorizer(ngram_range=(1, 2), min_df=2)
    clf = LogisticRegression(max_iter=2000, class_weight="balanced").fit(tfidf.fit_transform(train["text"]), train["label"])
    preds["TF-IDF kata 1-2 gram + regresi logistik"] = clf.predict(tfidf.transform(texts))
    for seed in [SEED] + EXTRA_SEEDS:
        for mode in ["baseline", "augmented"]:
            folder = MODELS / mode if seed == SEED else MODELS / f"seed_{seed}" / mode
            if (folder / "config.json").exists():
                print(f"Prediksi {mode} seed {seed} ...", flush=True)
                preds[f"IndoBERT {mode} (seed {seed})"] = indobert_predict(folder, texts)

    # ---------- Laporan ----------
    n_dash = (filled["label"] == "-").sum()
    L = ["# Test ulasan baru berlabel buta", "",
         f"Ulasan Gojek yang terbit setelah ulasan terakhir dataset ({sheet['date'].min()[:10]} s.d. {sheet['date'].max()[:10]}), "
         f"diambil acak {len(sheet)} ulasan. Peneliti melabeli dari teks asli tanpa melihat rating, label leksikon/Claude, "
         "atau prediksi model. Model tidak dilatih ulang.", "",
         f"* Sudah dilabeli: {len(filled)} dari {len(sheet)}",
         f"* Netral / campur / tidak jelas (`-`, tidak dihitung): {n_dash} ({n_dash / max(1, len(filled)):.1%}) - "
         "ulasan seperti ini juga dibuang dari dataset saat pelabelan",
         f"* Dievaluasi: {len(test)} ulasan ({(y == 0).sum()} negatif, {(y == 1).sum()} positif)", "",
         "## 1. Kinerja", "", "Selang kepercayaan 95%: akurasi = Wilson, macro F1 = bootstrap 1.000 kali.", "",
         ] + performance(y, preds)

    fix = test["koreksi"].fillna("").str.strip() if "koreksi" in test else pd.Series("", index=test.index)
    changed = (fix.isin(["0", "1", "-"]) & (fix != test["label"])).values
    if changed.any():
        y_fix = np.where(changed, fix, test["label"])
        keep = y_fix != "-"
        L += ["", "### Setelah koreksi peneliti (angka tambahan)", "",
              f"{changed.sum()} label dikoreksi (no {', '.join(map(str, test.loc[changed, 'no']))}) setelah prediksi terlihat. "
              "Yang dicek hanya ulasan yang salah diprediksi, jadi angka ini cenderung menguntungkan model; "
              "angka utama tetap tabel di atas.", ""]
        L += performance(y_fix[keep].astype(int), {k: v[keep] for k, v in preds.items()})

    L += ["", "## 2. McNemar baseline vs augmentasi (seed sama)", "",
          "| Seed | Baseline benar, aug salah | Baseline salah, aug benar | p-value |", "|---|---|---|---|"]
    for seed in [SEED] + EXTRA_SEEDS:
        b, a = preds.get(f"IndoBERT baseline (seed {seed})"), preds.get(f"IndoBERT augmented (seed {seed})")
        if b is not None and a is not None:
            only_b, only_a, pv = mcnemar(y, b, a)
            L.append(f"| {seed} | {only_b} | {only_a} | {pv:.4f} |")

    main = {"baseline": f"IndoBERT baseline (seed {SEED})", "augmented": f"IndoBERT augmented (seed {SEED})"}
    L += ["", f"## 3. Ulasan yang salah diprediksi (seed {SEED})", "",
          "| No | Teks asli | Label manusia | Baseline | Augmented |", "|---|---|---|---|---|"]
    for i in np.where((preds[main["baseline"]] != y) | (preds[main["augmented"]] != y))[0]:
        raw = str(test.loc[i, "raw_text"]).replace("|", "/").replace("\n", " ")
        L.append(f"| {test.loc[i, 'no']} | {raw} | {y[i]} | {preds[main['baseline']][i]} | {preds[main['augmented']][i]} |")

    # Ulasan `-`: model tetap memaksa memilih positif/negatif -> berapa yang dianggap positif?
    dash = filled[filled["label"] == "-"]
    if len(dash) and main["baseline"] in preds:
        dp = indobert_predict(MODELS / "baseline", dash["text"].tolist())
        L += ["", f"Ulasan `-` ({len(dash)}): IndoBERT baseline seed {SEED} memprediksi {(dp == 1).sum()} positif, "
              f"{(dp == 0).sum()} negatif. Model biner selalu memilih salah satu; inilah batas pendekatan dua kelas."]

    text = "\n".join(L)
    (RESULTS / "fresh_test.md").write_text(text, encoding="utf-8")
    json.dump({k: v.tolist() for k, v in preds.items()}, open(RESULTS / "fresh_test_predictions.json", "w"))
    print(text)


parser = argparse.ArgumentParser()
parser.add_argument("step", choices=["scrape", "evaluate"])
{"scrape": scrape, "evaluate": evaluate}[parser.parse_args().step]()
