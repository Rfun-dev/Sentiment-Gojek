"""Pembungkus LLM (Google Gemini). Dipakai untuk pelabelan (tahap 3) dan augmentasi (tahap 5).
API key dibaca dari file .env (GEMINI_API_KEY=...) atau environment variable.
Free tier Gemini dibatasi per menit DAN per hari, jadi kode ini menunggu saat kena batas
per menit, dan pindah model saat batas harian satu model habis.
Ingin pakai LLM lain? Cukup ubah fungsi ask_json() di file ini."""
import json
import os
import re
import time

import requests

from config import BASE, LLM_MODELS


def _load_key():
    if os.environ.get("GEMINI_API_KEY"):
        return os.environ["GEMINI_API_KEY"]
    env = BASE / ".env"
    if env.exists():
        for line in env.read_text().splitlines():
            if line.startswith("GEMINI_API_KEY="):
                return line.split("=", 1)[1].strip()
    raise RuntimeError("GEMINI_API_KEY tidak ditemukan (isi file .env)")


API_KEY = _load_key()
_model_idx = 0          # model yang sedang dipakai (indeks di LLM_MODELS)


def ask_json(prompt: str, retries: int = 12):
    """Kirim prompt, harapkan jawaban berupa JSON list. Return list (atau None kalau gagal)."""
    global _model_idx
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.7, "responseMimeType": "application/json"},
    }
    for attempt in range(retries):
        model = LLM_MODELS[_model_idx]
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        try:
            r = requests.post(url, json=body, headers={"x-goog-api-key": API_KEY}, timeout=120)
            if r.status_code == 429 and "PerDay" in r.text:       # kuota harian model ini habis
                if _model_idx + 1 >= len(LLM_MODELS):
                    raise RuntimeError("Kuota harian semua model LLM habis. Coba lagi besok / tambah model di config.py")
                _model_idx += 1
                print(f"  Kuota harian {model} habis -> pindah ke {LLM_MODELS[_model_idx]}")
                continue
            if r.status_code in (429, 500, 503):                  # batas per menit / server sibuk -> tunggu
                time.sleep(15 + 5 * attempt)
                continue
            r.raise_for_status()
            parts = r.json()["candidates"][0]["content"]["parts"]
            text = "".join(p.get("text", "") for p in parts)
            return json.loads(re.search(r"\[.*\]", text, re.S).group(0))
        except RuntimeError:
            raise
        except Exception as e:
            print(f"  LLM error (percobaan {attempt + 1}): {str(e)[:100]}")
            time.sleep(3)
    return None
