"""TAHAP 3 - Pelabelan otomatis: bandingkan InSet Lexicon vs LLM.
  - Hasil SAMA (sama-sama positif/negatif)  -> label dipakai langsung
  - Leksikon ambigu, LLM positif/negatif   -> ikut label LLM (aturan dilonggarkan)
  - Hasil BERBEDA / ambigu / netral          -> masuk data/manual_label.csv untuk diisi manual
Input : data/reviews_clean.csv
Output: data/labeled_auto.csv, data/manual_label.csv  (+ cache data/llm_labels.csv)"""
from concurrent.futures import ThreadPoolExecutor

import pandas as pd
from sklearn.metrics import cohen_kappa_score
from tqdm import tqdm

from config import DATA, LLM_BATCH, LLM_WORKERS, TAU
from text_utils import lexicon_score

df = pd.read_csv(DATA / "reviews_clean.csv")

# ---------- A. Label leksikon ----------
df["lex_score"] = df["text"].map(lexicon_score)
df["lex_label"] = df["lex_score"].map(lambda s: "positif" if s >= TAU else "negatif" if s <= -TAU else "ambigu")

# ---------- B. Label LLM (dengan cache supaya bisa dilanjutkan kalau terputus) ----------
cache_file = DATA / "llm_labels.csv"
cache = pd.read_csv(cache_file) if cache_file.exists() else pd.DataFrame(columns=["id", "llm_label"])
todo = df[~df["id"].isin(cache["id"])]
print(f"Ulasan perlu dilabeli LLM: {len(todo)} (sudah di cache: {len(cache)})")

PROMPT = """Kamu adalah annotator sentimen ulasan aplikasi Gojek (bahasa Indonesia, sering tidak baku).
Beri label tiap ulasan: "positif", "negatif", atau "netral" (tidak ada opini jelas / campuran seimbang).
Perhatikan sarkasme dan negasi (misal "tidak bagus" = negatif).
Balas HANYA JSON list: [{{"i": 0, "label": "positif"}}, ...]

Ulasan:
{reviews}"""


def label_batch(chunk: pd.DataFrame):
    from llm import ask_json          # baru dimuat kalau memang perlu memanggil API
    reviews = "\n".join(f"{i}. {t[:300]}" for i, t in enumerate(chunk["raw_text"]))
    answer = ask_json(PROMPT.format(reviews=reviews))
    if not answer:
        return []
    out = []
    for item in answer:
        try:
            lab = str(item["label"]).lower()
            out.append((chunk["id"].iloc[int(item["i"])], lab if lab in ("positif", "negatif") else "netral"))
        except (KeyError, IndexError, ValueError, TypeError):
            continue
    return out


chunks = [todo.iloc[i:i + LLM_BATCH] for i in range(0, len(todo), LLM_BATCH)]
new_rows = []
with ThreadPoolExecutor(LLM_WORKERS) as pool:
    for k, res in enumerate(tqdm(pool.map(label_batch, chunks), total=len(chunks), desc="LLM labeling")):
        new_rows += res
        if k % 5 == 0 and new_rows:      # simpan berkala
            pd.concat([cache, pd.DataFrame(new_rows, columns=["id", "llm_label"])]).to_csv(cache_file, index=False)
cache = pd.concat([cache, pd.DataFrame(new_rows, columns=["id", "llm_label"])]).drop_duplicates("id")
cache.to_csv(cache_file, index=False)

df = df.merge(cache, on="id", how="left")
df["llm_label"] = df["llm_label"].fillna("netral")        # gagal dilabeli -> diperiksa manual

# ---------- C. Bandingkan ----------
llm_polar = df["llm_label"].isin(["positif", "negatif"])
both_same = (df["lex_label"] == df["llm_label"]) & llm_polar
lex_ambiguous = (df["lex_label"] == "ambigu") & llm_polar     # aturan dilonggarkan: leksikon ambigu -> ikut LLM
agree = both_same | lex_ambiguous
both = df[df["lex_label"].isin(["positif", "negatif"]) & df["llm_label"].isin(["positif", "negatif"])]
if len(both):
    print(f"Cohen's kappa leksikon vs LLM (yang sama-sama berpolaritas): {cohen_kappa_score(both.lex_label, both.llm_label):.3f}")
print(f"Sepakat: {agree.sum()} ({agree.mean():.1%}) | Perlu manual: {(~agree).sum()} ({(~agree).mean():.1%})")

auto = df[agree].copy()
auto["label"] = (auto["llm_label"] == "positif").astype(int)
auto["source"] = auto["lex_label"].map(lambda s: "llm (leksikon ambigu)" if s == "ambigu" else "lexicon+llm")
auto[["id", "text", "label", "source"]].to_csv(DATA / "labeled_auto.csv", index=False)

# ---------- D. File untuk anotasi manual (jangan timpa isian yang sudah ada) ----------
manual = df[~agree][["id", "raw_text", "text", "rating", "lex_score", "lex_label", "llm_label"]].copy()
manual["manual_label"] = ""
manual_file = DATA / "manual_label.csv"
if manual_file.exists():
    old = pd.read_csv(manual_file, encoding="utf-8-sig", dtype={"manual_label": str})[["id", "manual_label"]]
    manual = manual.drop(columns="manual_label").merge(old, on="id", how="left")
    print("manual_label.csv sudah ada -> isian lama dipertahankan")
manual.to_csv(manual_file, index=False, encoding="utf-8-sig")
print(f"\nBuka data/manual_label.csv, isi kolom manual_label: 1 = positif, 0 = negatif, kosong = buang.")
